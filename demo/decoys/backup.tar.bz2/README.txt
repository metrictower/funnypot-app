Full backup split across the enclosed archive. Continue unpacking.
